from django.contrib import admin
from .models import EmployeeDetails
# Register your models here.

class EmployeeDetailsAdmin(admin.ModelAdmin):
    list_display = ('id', 'emp_name','emp_salary','hr_id',)
    list_editable = ('emp_name',)
    search_fields = ('emp_name','emp_salary')

   


admin.site.register(EmployeeDetails,EmployeeDetailsAdmin)
