from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class EmployeeDetails(models.Model):
    """

    Model representing a ExamSeries

    """
    emp_name = models.CharField(max_length=100)
    emp_salary = models.CharField(max_length=100)
    hr_id = models.ForeignKey(User, on_delete=models.PROTECT)

    class Meta:
        verbose_name = 'EmployeeDetails'

    def __str__(self):
        """
        String for representing the Model object.
        """
        return "%s-%s" % (str(self.emp_name), str(self.emp_salary))
