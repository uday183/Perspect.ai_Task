from django.shortcuts import render
from rest_framework.views import APIView 
from rest_framework.response import Response 
from rest_framework.permissions import IsAuthenticated
from rest_framework import permissions
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from .models import EmployeeDetails
# Create your views here.

class UserLogin(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self,request):
        username = request.data.get("username",None)
        password = request.data.get("password",None)

        if username is None or password is None:
            return Response({'error': 'Please provide both username and password'})
        user = authenticate(username=username,password=password)
        if not user:
            return Response({'error': 'Invalid Credentials'})
       
        #JWT token
        refresh = RefreshToken.for_user(user)
        return Response({'message': 'success','refresh_token': str(refresh),'access_token': str(refresh.access_token),})

class HrOnboard(APIView):
    def post(self, request):
        response_dict = {"status": True, "message": "data saved.", "data": {}}
        try:
            username=request.data.get('username')
            email=request.data.get('email')
            password=request.data.get('password')
            first_name=request.data.get('first_name')
            last_name=request.data.get('last_name')
            user = User.objects.create_user(username,email,password)
            user.save()
            User.objects.filter(pk =user.id).update(first_name=first_name,last_name=last_name)
        except Exception as e:
            response_dict['status'] = False
            response_dict['message'] = 'something went wrong'
        return Response(response_dict)

class EmployeeCrud(APIView): 
    permission_classes = (IsAuthenticated, ) 
    def get(self, request):
        response_dict = {"status": True, "message": "", "data": {}}
        try:
            emp_obj = EmployeeDetails.objects.filter(hr_id=request.user.id)
            if not emp_obj.exists():
                response_dict['status'] = False
                response_dict['message'] = 'data not available'
            result = []
            for each in emp_obj:
                d={}
                d['emp_name'] = each.emp_name
                d['emp_salary'] = each.emp_salary
                result.append(d)
            response_dict['data'] = result
        except Exception as e:
            response_dict['status'] = False
            response_dict['message'] = 'something went wrong'
        return Response(response_dict)

    def post(self, request):
        response_dict = {"status": True, "message": "data saved.", "data": {}}
        try:
            emp_name = request.data.get('emp_name')
            emp_salary = request.data.get('emp_salary')
            emp_obj = EmployeeDetails.objects.create(hr_id=User.objects.get(pk=request.user.id),emp_name=emp_name,emp_salary=emp_salary)
        except Exception as e:
            response_dict['status'] = False
            response_dict['message'] = 'something went wrong'
        return Response(response_dict)

    def put(self, request):
        response_dict = {"status": True, "message": "data updated.", "data": {}}
        try:
            emp_name = request.data.get('emp_name')
            emp_salary = request.data.get('emp_salary')
            emp_obj = EmployeeDetails.objects.filter(hr_id=request.user.id,emp_name=emp_name).update(emp_salary=emp_salary)
        except Exception as e:
            response_dict['status'] = False
            response_dict['message'] = 'something went wrong'
        return Response(response_dict)

    def delete(self, request):
        response_dict = {"status": True, "message": "data deletd.", "data": {}}
        try:
            emp_id = request.data.get('emp_id')
            EmployeeDetails.objects.filter(hr_id=request.user.id, pk=emp_id).delete()
        except Exception as e:
            response_dict['status'] = False
            response_dict['message'] = 'something went wrong'
        return Response(response_dict)




